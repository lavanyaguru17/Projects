import Product from './components/Product';
import Layout from './components/Layout';
import React from 'react';

import { Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Routes>
      
      <Route path='/no' element={<Product />} />
      <Route path='/' element={<Layout />}></Route>




    </Routes>
  );
}

export default App;
