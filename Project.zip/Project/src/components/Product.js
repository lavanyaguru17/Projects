import React from 'react';
// import './App.css'; // Import your CSS files here
// Import Bootstrap and other CSS files as needed

const Product = () => {
  return (
    <div>
      {/* Header Area */}
      <header className="header-area header-sticky">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <nav className="main-nav">
                <a href="index.html" className="logo">Logo</a>
                <ul className="nav">
                  <li><a href="index.html" className="active">Home</a></li>
                  <li className="has-sub">
                    <a href="javascript:void(0)">Product</a>
                    <ul className="sub-menu">
                      <li><a href="sports.html">Sports</a></li>
                      <li><a href="agri.html">Agri</a></li>
                      <li><a href="ocr.html">OCR</a></li>
                    </ul>
                  </li>
                  <li className="has-sub">
                    <a href="javascript:void(0)">Services</a>
                    <ul className="sub-menu">
                      <li><a href="consulting.html">Consulting</a></li>
                      <li><a href="bootcamp.html">Bootcamp</a></li>
                      <li><a href="hireandmanage.html">Hire & Manage</a></li>
                      <li><a href="training.html">Training</a></li>
                    </ul>
                  </li>
                  <li className="has-sub">
                    <a href="javascript:void(0)">About Us</a>
                    <ul className="sub-menu">
                      <li><a href="aboutus.html">About Company</a></li>
                      <li><a href="insights.html">Insights</a></li>
                    </ul>
                  </li>
                  <li className="has-sub">
                    <a href="javascript:void(0)">Careers</a>
                    <ul className="sub-menu">
                      <li><a href="pagetosupport.html">Page to Support</a></li>
                      <li><a href="jobPosting.html">Job Posting</a></li>
                    </ul>
                  </li>
                  <li className="has-sub">
                    <a href="javascript:void(0)">Contact Us</a>
                    <ul className="sub-menu">
                      <li><a href="contactpage.html">Contact Page</a></li>
                    </ul>
                  </li>
                </ul>
                <a className='menu-trigger'><span>Menu</span></a>
              </nav>
            </div>
          </div>
        </div>
      </header>

      {/* Main Banner Area */}
      <section className="section main-banner" id="top" data-section="section1">
        <div id="bg-video">
          {/* Background video can be added here */}
        </div>
        <div className="video-overlay header-text">
          <div className="container">
            <div className="row">
              <div className="col-lg-12">
                <div className="caption">
                  <h6>TBD</h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer Area */}
      <section className="contact-us" id="contact">
        <div className="container">
          <div className="row">
            <div className="col-lg-9 align-self-center">
              <div className="row">
                <div className="col-lg-12">
                  <form id="contact" action="" method="post">
                    <div className="row">
                      <div className="col-lg-12">
                        <h2>Let's get in touch</h2>
                      </div>
                      <div className="col-lg-4">
                        <fieldset>
                          <input name="name" type="text" id="name" placeholder="YOUR NAME...*" required />
                        </fieldset>
                      </div>
                      <div className="col-lg-4">
                        <fieldset>
                          <input name="email" type="email" id="email" placeholder="YOUR EMAIL..." required />
                        </fieldset>
                      </div>
                      <div className="col-lg-4">
                        <fieldset>
                          <input name="subject" type="text" id="subject" placeholder="SUBJECT...*" required />
                        </fieldset>
                      </div>
                      <div className="col-lg-12">
                        <fieldset>
                          <textarea name="message" className="form-control" id="message" placeholder="YOUR MESSAGE..." required></textarea>
                        </fieldset>
                      </div>
                      <div className="col-lg-12">
                        <fieldset>
                          <button type="submit" id="form-submit" className="button">SEND MESSAGE NOW</button>
                        </fieldset>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div className="col-lg-3">
              <div className="right-info">
                <ul>
                  <li>
                    <h6>Phone Number</h6>
                    <span>123-456-7890</span>
                  </li>
                  <li>
                    <h6>Email Address</h6>
                    <span>info@pradeepan.com</span>
                  </li>
                  <li>
                    <h6>Street Address</h6>
                    <span>Address line1, address line 2, address line 3</span>
                  </li>
                  <li>
                    <h6>Website URL</h6>
                    <span>www.pradeepsite.com</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="footer">
          <p>Copyright © 2024 Pradeepan Co., Ltd. All Rights Reserved.</p>
        </div>
      </section>

      {/* Scripts */}
      {/* Load JavaScript libraries in the public/index.html or use useEffect hook in React for custom scripts */}
    </div>
  );
};

export default Product;
