// Layout.js
import React from 'react';
import Header from './Header';
import Footer from './Footer';
import Banner from './Banner';
import Services from './Services';
import Upcomingworkshops from './Upcomingworkshops';

const Layout = ({ children }) => {
  return (
    <>
      <Header />
      <Banner />
      <Services/>
      <Upcomingworkshops/>
      {children}
      <Footer />
    </>
  );
};

export default Layout;
