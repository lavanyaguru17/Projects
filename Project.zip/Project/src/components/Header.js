import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../assets/css/fontawesome.css';
import '../assets/css/root.css';
// import '../assets/css/owl.css';
import '../assets/css/lightbox.css';
// import '../vendor/bootstrap/css/bootstrap.min.css';

const Header = () => {
  return (
    <header className="header-area header-sticky">
      <div className="container">
        <div className="row">
          <div className="col-12">
            <nav className="main-nav">
              <a href="/" className="logo">
                Logo
              </a>
              <ul className="nav">
                <li><a href="/" className="active">Home</a></li>
                <li className="has-sub">
                  <a href="#">Product</a>
                  <ul className="sub-menu">
                    <li><a href="/sports">Sports</a></li>
                    <li><a href="/agri">Agri</a></li>
                    <li><a href="/ocr">OCR</a></li>
                  </ul>
                </li>
                <li className="has-sub">
                  <a href="#">Services</a>
                  <ul className="sub-menu">
                    <li><a href="/consulting">Consulting</a></li>
                    <li><a href="/bootcamp">Bootcamp</a></li>
                    <li><a href="/hireandmanage">Hire & Manage</a></li>
                    <li><a href="/training">Training</a></li>
                  </ul>
                </li>
                <li className="has-sub">
                  <a href="#">Aboutus</a>
                  <ul className="sub-menu">
                    <li><a href="/aboutus">About Company</a></li>
                    <li><a href="/insights">Insights</a></li>
                  </ul>
                </li>
                <li className="has-sub">
                  <a href="#">Careers</a>
                  <ul className="sub-menu">
                    <li><a href="/pagetosupport">Page to Support</a></li>
                    <li><a href="/jobPosting">Job Posting</a></li>
                  </ul>
                </li>
                <li className="has-sub">
                  <a href="#">Contact Us</a>
                  <ul className="sub-menu">
                    <li><a href="/contactpage">Contact Page</a></li>
                  </ul>
                </li>
              </ul>
              <a className='menu-trigger'>
                <span>Menu</span>
              </a>
            </nav>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
