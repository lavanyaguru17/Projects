import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../assets/css/fontawesome.css';
import '../assets/css/root.css';
import 'slick-carousel/slick/slick.css'; // slick styles
import 'slick-carousel/slick/slick-theme.css'; // slick theme styles

import serviceIcon01 from '../assets/images/service-icon-01.png';
import serviceIcon02 from '../assets/images/service-icon-02.png';
import serviceIcon03 from '../assets/images/service-icon-03.png';
import Slider from 'react-slick';

const Services = () => {
  // Slick carousel settings
  const settings = {
    dots: true, // Show navigation dots
    infinite: true, // Infinite scroll
    speed: 500, // Animation speed
    slidesToShow: 3, // Show one slide at a time
    slidesToScroll: 3, // Scroll one slide at a time
    autoplay: true,
    autoplaySpeed: 2000,

  };

  return (
    <section className="services">
      <div className="container">
        <div className="row">
          <div className="col-lg-12">
            <Slider {...settings}>
              {/* Service 1 */}
              <div className="item">
                <div className="icon">
                  <img src={serviceIcon01} alt="Best Services" />
                </div>
                <div className="down-content">
                  <h4>Best Services</h4>
                  <p>Suspendisse tempor mauris a sem elementum bibendum.</p>
                </div>
              </div>
              
              {/* Service 2 */}
              <div className="item">
                <div className="icon">
                  <img src={serviceIcon02} alt="Best Mentors" />
                </div>
                <div className="down-content">
                  <h4>Best Mentors</h4>
                  <p>Suspendisse tempor mauris a sem elementum bibendum. Praesent facilisis massa non vestibulum.</p>
                </div>
              </div>

              {/* Service 3 */}
              <div className="item">
                <div className="icon">
                  <img src={serviceIcon03} alt="Best Authors" />
                </div>
                <div className="down-content">
                  <h4>Best Authors</h4>
                  <p>Suspendisse tempor mauris a sem elementum bibendum. Praesent facilisis massa non vestibulum.</p>
                </div>
              </div>

              {/* Service 4 */}
              <div className="item">
                <div className="icon">
                  <img src={serviceIcon02} alt="Meeting Schedules" />
                </div>
                <div className="down-content">
                  <h4>Meeting Schedules</h4>
                  <p>Suspendisse tempor mauris a sem elementum bibendum. Praesent facilisis massa non vestibulum.</p>
                </div>
              </div>

              {/* Service 5 */}
              <div className="item">
                <div className="icon">
                  <img src={serviceIcon03} alt="Best Networking" />
                </div>
                <div className="down-content">
                  <h4>Best Networking</h4>
                  <p>Suspendisse tempor mauris a sem elementum bibendum. Praesent facilisis massa non vestibulum.</p>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
