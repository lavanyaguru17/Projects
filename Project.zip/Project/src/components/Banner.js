// Banner.js
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../assets/css/fontawesome.css';
import '../assets/css/root.css';
import '../assets/css/owl.css';
import '../assets/css/lightbox.css';
import '../assets/images/course-video.mp4'
const Banner = () => {
  return (
    <section className="section main-banner" id="top" data-section="section1">
      {/* Background video container */}
      <div id="bg-video">
        {/* Uncomment and add video source if needed */}
        {/* <source src="assets/images/course-video.mp4" type="video/mp4" /> */}
      </div>
      <div className="video-overlay header-text">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div className="caption">
                <h6>Hello Customer</h6>
                <h2>Welcome to best workshop's platform</h2>
                <p>This is a responsive website for a user-friendly</p>
                <div className="main-button-red">
                  <div className="scroll-to-section">
                    <a href="#contact">Join Us Now!</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Banner;
