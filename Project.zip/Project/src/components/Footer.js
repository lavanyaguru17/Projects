import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../assets/css/fontawesome.css';
import '../assets/css/root.css';
// import '../assets/css/owl.css';
import '../assets/css/lightbox.css';

const Footer = () => {
  return (
    <section className="contact-us" id="contact">
      <div className="container">
        <div className="row">
          <div className="col-lg-9 align-self-center">
            <form id="contact" action="" method="post">
              <div className="row">
                <div className="col-lg-12">
                  <h2>Let's get in touch</h2>
                </div>
                
                {/* Form fields here */}
                <div className="col-lg-4">
                  <fieldset>
                    <input name="name" type="text" id="name" placeholder="YOUR NAME..." required />
                  </fieldset>
                </div>
                <div className="col-lg-4">
                  <fieldset>
                    <input name="email" type="text" id="email" pattern="[^ @]*@[^ @]*" placeholder="YOUR EMAIL..." required />
                  </fieldset>
                </div>
                <div className="col-lg-4">
                  <fieldset>
                    <input name="subject" type="text" id="subject" placeholder="SUBJECT..." required />
                  </fieldset>
                </div>
                <div className="col-lg-12">
                  <fieldset>
                    <textarea name="message" className="form-control" id="message" placeholder="YOUR MESSAGE..." required></textarea>
                  </fieldset>
                </div>
                <div className="col-lg-12">
                  <fieldset>
                    <button type="submit" id="form-submit" className="button">SEND MESSAGE NOW</button>
                  </fieldset>
                </div>
              </div>
            </form>
          </div>
          <div className="col-lg-3">
            <div className="right-info">
              <ul>
                <li><h6>Phone Number</h6><span>123-456-7890</span></li>
                <li><h6>Email Address</h6><span>info@pradeepan.com</span></li>
                <li><h6>Street Address</h6><span>Address line 1, line 2</span></li>
                <li><h6>Website URL</h6><span>www.pradeepsite.com</span></li>
              </ul>
            </div>
          </div>
        </div>
        <div className="footer">
          <div className="sub-header">
            <div class="container">
            <div class="row">
                <div class="col-lg-8 col-sm-8">
                    <div class="left-content">
            <p>Copyright © 2024 <em>Pradeepan Co.,</em> Ltd. All Rights Reserved.</p>
           </div>
           </div>
           <div class="col-lg-4 col-sm-4">
           <div className="right-icons">

            <ul>
              <li><a href="#"><i className="fa fa-facebook"></i></a></li>
              <li><a href="#"><i className="fa fa-twitter"></i></a></li>
              <li><a href="#"><i className="fa fa-linkedin"></i></a></li>
            </ul>
          </div>
        </div>
        </div>
        </div>
        </div>
        </div>
      </div>
    </section>
  );
};

export default Footer;

