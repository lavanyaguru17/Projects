import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../assets/css/fontawesome.css';
import '../assets/css/root.css';
// import '../assets/css/owl.css';
import '../assets/css/lightbox.css';

// Import images
import meeting01 from '../assets/images/meeting-01.jpg';
import meeting02 from '../assets/images/meeting-02.jpg';
import meeting03 from '../assets/images/meeting-03.jpg';
import meeting04 from '../assets/images/meeting-04.jpg';

const Upcomingworkshops = () => {
  return (
    <section className="upcoming-meetings" id="meetings">
      <div className="container">
        <div className="row">
          <div className="col-lg-12">
            <div className="section-heading">
              <h2>Upcoming Workshops</h2>
            </div>
          </div>
          <div className="col-lg-4">
            <div className="categories">
              <h4>Workshop Categories</h4>
              <ul>
                <li><a href="#">Sed tempus enim leo</a></li>
                <li><a href="#">Aenean molestie quis</a></li>
                <li><a href="#">Cras et metus vestibulum</a></li>
                <li><a href="#">Nam et condimentum</a></li>
                <li><a href="#">Phasellus nec sapien</a></li>
              </ul>
              <div className="main-button-red">
                <a href="meetings.html">All Upcoming Workshops</a>
              </div>
            </div>
          </div>
          <div className="col-lg-8">
            <div className="row">
              <MeetingItem
                price="$22.00"
                date={{ day: "10", month: "Nov" }}
                imgSrc={meeting01}
                title="New Lecturers Meeting"
                link="meeting-details.html"
                description="Morbi in libero blandit lectus cursus ullamcorper."
              />
              <MeetingItem
                price="$36.00"
                date={{ day: "24", month: "Nov" }}
                imgSrc={meeting02}
                title="Online Training Techniques"
                link="meeting-details.html"
                description="Morbi in libero blandit lectus cursus ullamcorper."
              />
              <MeetingItem
                price="$14.00"
                date={{ day: "26", month: "Nov" }}
                imgSrc={meeting03}
                title="Higher Teaching Conference"
                link="meeting-details.html"
                description="Morbi in libero blandit lectus cursus ullamcorper."
              />
              <MeetingItem
                price="$48.00"
                date={{ day: "30", month: "Nov" }}
                imgSrc={meeting04}
                title="Peoples Training Meetup"
                link="meeting-details.html"
                description="Morbi in libero blandit lectus cursus ullamcorper."
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const MeetingItem = ({ price, date, imgSrc, title, link, description }) => {
  return (
    <div className="col-lg-6">
      <div className="meeting-item">
        <div className="thumb">
          <div className="price">
            <span>{price}</span>
          </div>
          <a href={link}><img src={imgSrc} alt={title} /></a>
        </div>
        <div className="down-content">
          <div className="date">
            <h6>{date.month} <span>{date.day}</span></h6>
          </div>
          <a href={link}><h4>{title}</h4></a>
          <p>{description}</p>
        </div>
      </div>
    </div>
  );
};

export default Upcomingworkshops;
